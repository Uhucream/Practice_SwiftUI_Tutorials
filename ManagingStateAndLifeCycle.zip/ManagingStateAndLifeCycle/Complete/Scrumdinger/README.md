# Managing State and Life Cycle

## Completed Project

Explore the completed project for the [Managing State and Life Cycle](https://developer.apple.com/tutorials/apt-app-dev-training/managing-state-and-life-cycle) tutorial.
