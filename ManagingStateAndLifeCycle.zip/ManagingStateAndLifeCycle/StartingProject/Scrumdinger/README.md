# Managing State and Life Cycle

## Starting Project

Use this project to code along with the [Managing State and Life Cycle](https://developer.apple.com/tutorials/apt-app-dev-training/managing-state-and-life-cycle) tutorial.
