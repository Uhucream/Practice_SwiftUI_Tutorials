# Passing Data With Bindings
## Completed Project

Explore the completed project for the [Passing Data With Bindings](https://developer.apple.com/tutorials/app-dev-training/passing-data-with-bindings) tutorial.


