# Passing Data With Bindings
## Starting Project

Use this project to code along with the [Passing Data With Bindings](https://developer.apple.com/tutorials/app-dev-training/passing-data-with-bindings) tutorial.

## Change Log
### Models/DailyScrum.swift
* Adds mutating function to update the values of a `DailyScrum` from a `DailyScrum.Data`


