# Displaying Data in a List
## Starting Project

Use this project to code along with the [Displaying Data in a List](https://developer.apple.com/tutorials/app-dev-training/displaying-data-in-a-list) tutorial.


