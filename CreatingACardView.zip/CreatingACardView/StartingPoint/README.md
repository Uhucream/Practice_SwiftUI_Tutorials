# Creating a CardView
## Starting Project

Use this project to code along with the [Creating a CardView](https://developer.apple.com/tutorials/app-dev-training/creating-a-cardview) tutorial.

## Change Log
### Models/Color+Codable.swift
* Adds `Codable` conformance to `Color`
* Adds property to generate a random color


